/* rand.h for openSSL */

#include <wolfssl/openssl/ssl.h>
#include <wolfssl/wolfcrypt/random.h>

#define RAND_set_rand_method     wolfSSL_RAND_set_rand_method
