#!/bin/bash

gcc *.c ./lib/wolfmqtt/*.c -I./include/mqtt/ -Wall
